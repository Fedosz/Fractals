﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace frctls1
{
    class Koha : Fractals
    {
        /// <summary>
        /// Создаем новый фрактал
        /// </summary>
        /// <param name="depth"></param>
        /// <param name="name"></param>
        public Koha(int depth, Canvas name) : base(depth, name)
        {
            if (depth != 0)
                DrawKoha(800, 390, 100, 390, depth, name);
            else
            {
                // При глубине 0 рисуем простую линию
                Line line = new Line();
                line.Stroke = Brushes.Black;
                (line.X1, line.Y1, line.X2, line.Y2) = (800, 390, 100, 390);
                name.Children.Add(line);
            }

        }
        /// <summary>
        /// Рисуем рекурсию.
        /// </summary>
        /// <param name="xA"></param>
        /// <param name="yA"></param>
        /// <param name="xB"></param>
        /// <param name="yB"></param>
        /// <param name="depth"></param>
        /// <param name="canv"></param>
        private void DrawKoha(double xA, double yA, double xB, double yB, int depth, Canvas canv)
        { 
            //По формулам вычисляем точки фрактала.
            double xA1 = (2 * xA + xB) / 3;
            double yA1 = (2 * yA + yB) / 3;
            double xC = (xB + xA) / 2 + (yA - yB) / (2 * Math.Sqrt(3));
            double yC = (yB + yA) / 2 + (xB - xA) / (2 * Math.Sqrt(3));
            double xB1 = (xA + 2 * xB) / 3;
            double yB1 = (yA + 2 * yB) / 3;
            // По этим точкам строим новые линии.
            Line line = new Line();
            line.Stroke = Brushes.Black;
            (line.X1, line.Y1, line.X2, line.Y2) = (xA, yA, xA1, yA1);
            Line secondLine = new Line();
            secondLine.Stroke = Brushes.Black;
            (secondLine.X1, secondLine.Y1, secondLine.X2, secondLine.Y2) = (xA1, yA1, xC, yC);
            Line thirdLine = new Line();
            thirdLine.Stroke = Brushes.Black;
            (thirdLine.X1, thirdLine.Y1, thirdLine.X2, thirdLine.Y2) = (xC, yC, xB1, yB1);
            Line fourthLine = new Line();
            fourthLine.Stroke = Brushes.Black;
            (fourthLine.X1, fourthLine.Y1, fourthLine.X2, fourthLine.Y2) = (xB1, yB1, xB, yB);
            canv.Children.Add(line);
            canv.Children.Add(secondLine);
            canv.Children.Add(thirdLine);
            canv.Children.Add(fourthLine);
            //Добалвяем полупрозрачную линию(да побольше) чтобы было видно на каком месте производятся итерации.
            Line deleteLine = new Line();
            deleteLine.Stroke = Brushes.White;
            (deleteLine.X1, deleteLine.Y1, deleteLine.X2, deleteLine.Y2) = (xA1, yA1, xB1, yB1);
            canv.Children.Add(deleteLine);
            Line deleteLine1 = new Line();
            deleteLine1.Stroke = Brushes.White;
            (deleteLine1.X1, deleteLine1.Y1, deleteLine1.X2, deleteLine1.Y2) = (xA1, yA1, xB1, yB1);
            canv.Children.Add(deleteLine1);
            Line deleteLine2 = new Line();
            deleteLine2.Stroke = Brushes.White;
            (deleteLine2.X1, deleteLine2.Y1, deleteLine2.X2, deleteLine2.Y2) = (xA1, yA1, xB1, yB1);
            canv.Children.Add(deleteLine2);
            if (depth > 1)
            {
                DrawKoha(xA, yA, xA1, yA1, depth - 1, canv);
                DrawKoha(xA1, yA1, xC, yC, depth - 1, canv);
                DrawKoha(xC, yC, xB1, yB1, depth - 1, canv);
                DrawKoha(xB1, yB1, xB, yB, depth - 1, canv);
            }
            else
                return;
        }
    }
}
