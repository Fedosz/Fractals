﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;


namespace frctls1
{
    class CantorSet : Fractals
    {
        /// <summary>
        /// Создаем новый фрактал Кантора
        /// </summary>
        /// <param name="depth">Глубина фрактала</param>
        /// <param name="name">Название канваса</param>
        /// <param name="distance">Расстояние между отрезками</param>
        public CantorSet(int depth, Canvas name, int distance) : base(depth, name)
        {
            // Точка начала отрезка.
            Point A = new Point(150, 100);
            // Точка конца.
            Point B = new Point(700, 100);
            DrawLine(A, B, distance, depth, name);
        }
        /// <summary>
        /// Рисование фрактала.
        /// </summary>
        /// <param name="A">Точка начала</param>
        /// <param name="B">Точка Конца</param>
        /// <param name="dist">Расстояние между отрезками</param>
        /// <param name="depth">Глубина фрактала</param>
        /// <param name="canv">Название канваса</param>
        private void DrawLine(Point A, Point B, int dist, int depth, Canvas canv)
        {
            //Создаем линию и даем параметры.
            Line line = new Line();
            line.Stroke = Brushes.Black;
            line.StrokeThickness = 12;
            (line.X1, line.X2, line.Y1, line.Y2) = (A.X, B.X, A.Y, B.Y);
            //Добавляем линию на канвас.
            canv.Children.Add(line);
            //Находим координаты точек новых отрезков.
            Point A1 = new Point(A.X, A.Y + dist);
            Point A2 = new Point(A.X + (B.X - A.X) / 3, A.Y + dist);
            Point B1 = new Point(A.X + (B.X - A.X) / 3 * 2, A.Y + dist);
            Point B2 = new Point(B.X, A.Y + dist);
            //Пока не закончится глубина делаем рекурсию.
            if (depth > 0)
            {
                DrawLine(A1, A2, dist, depth - 1, canv);
                DrawLine(B1, B2, dist, depth - 1, canv);
            }
        }
    }
}
