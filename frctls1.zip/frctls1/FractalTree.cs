﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace frctls1
{
    class FractalTree : Fractals
    {
        //Отношение отрезков.
        private double lengthScale;
        //Левый наклон.
        private double leftIncline;
        //Правый наклон.
        private double rightIncline;
        //Переключатель цвета.
        private int color = 8;
        /// <summary>
        /// Создаем дерево
        /// </summary>
        /// <param name="depth"></param>
        /// <param name="name"></param>
        /// <param name="leftIncline"></param>
        /// <param name="rightIncline"></param>
        /// <param name="sizeDif"></param>
        public FractalTree(int depth, Canvas name, double leftIncline, double rightIncline, double sizeDif) : base(depth, name)
        {
            this.lengthScale = sizeDif;
            this.leftIncline = leftIncline;
            this.rightIncline = rightIncline;
            DrawBinaryTree(currentPanel, Depth, new Point(435, 560), 0.135 * currentPanel.Width, -Math.PI / 2, color);
        }
        /// <summary>
        /// Рисуем дерево
        /// </summary>
        /// <param name="canv"></param>
        /// <param name="depth"></param>
        /// <param name="pt"></param>
        /// <param name="length"></param>
        /// <param name="theta"></param>
        /// <param name="colorint"></param>
        private void DrawBinaryTree(Canvas canv, int depth, Point pt, double length, double theta, int colorint)
        {
            //Вычисляем координаты конца прямой
            double x1 = pt.X + length * Math.Cos(theta);
            double y1 = pt.Y + length * Math.Sin(theta);
            Line line = new Line();
            //Благодаря этому при рисовании фрактала глубины 8+ получится сакура.
            if (colorint <= 0)
                line.Stroke = Brushes.LightPink;
            else
                line.Stroke = Brushes.SaddleBrown;
            line.X1 = pt.X;
            line.Y1 = pt.Y;
            line.X2 = x1;
            line.Y2 = y1;
            canv.Children.Add(line);
            if (depth > 1)
            {
                DrawBinaryTree(canv, depth - 1, new Point(x1, y1), length * lengthScale, theta + rightIncline, colorint - 1);
                DrawBinaryTree(canv, depth - 1, new Point(x1, y1), length * lengthScale, theta - leftIncline, colorint - 1);
            }
            else
                return;
        }
    }
}

