﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace frctls1
{
    class SerpinskyCarpet : Fractals
    {
        /// <summary>
        /// Создаем новый фрактал 
        /// </summary>
        /// <param name="depth">Глубина фрактала</param>
        /// <param name="name">Название канваса</param>
        public SerpinskyCarpet(int depth, Canvas name) : base(depth, name)
        {
            // Левая верхняя вершина.
            Point A = new Point(220, 100);
            // Правая верхняя вершина.
            Point B = new Point(620, 100);
            // Левая нижняя вершина.
            Point C = new Point(620, 500);
            // Правая нижняя вершина.
            Point D = new Point(220, 500);
            // Рисуем стартовый квадрат.
            DrawStartingCarpet(A, B, C, D, name);
            // При глубине 0 заканчиваем на этом работу.
            if (depth != 0)
                DrawCarpet(A, B, C, D, depth, name);
        }
        /// <summary>
        /// Стартовый квадрат
        /// </summary>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <param name="C"></param>
        /// <param name="D"></param>
        /// <param name="canv"></param>
        private void DrawStartingCarpet(Point A, Point B, Point C, Point D, Canvas canv)
        {
            // По заданным координатам рисуем новый квадрат.
            Polygon start = new Polygon();
            PointCollection points = new PointCollection();
            points.Add(A);
            points.Add(B);
            points.Add(C);
            points.Add(D);
            start.Points = points;
            start.Fill = Brushes.Blue;
            canv.Children.Add(start);
        }
        /// <summary>
        /// Рисуем четыре квадрата.
        /// </summary>
        /// <param name="A"></param>
        /// <param name="B"></param>
        /// <param name="C"></param>
        /// <param name="D"></param>
        /// <param name="depth"></param>
        /// <param name="canv"></param>
        private void DrawCarpet(Point A, Point B, Point C, Point D, int depth, Canvas canv)
        {
            // Разбиваем квадрат на 9 меньших квадратов и находим координаты центрального.
            Point Ax = new Point(A.X + (B.X - A.X) / 3, A.Y + (D.Y - A.Y) / 3);
            Point Bx = new Point(A.X + (B.X - A.X) / 3 * 2, A.Y + (D.Y - A.Y) / 3);
            Point Cx = new Point(A.X + (B.X - A.X) / 3 * 2, A.Y + (D.Y - A.Y) / 3 * 2);
            Point Dx = new Point(A.X + (B.X - A.X) / 3, A.Y + (D.Y - A.Y) / 3 * 2);
            // Делаем его беленьким)
            Polygon white = new Polygon();
            PointCollection points = new PointCollection();
            points.Add(Ax);
            points.Add(Bx);
            points.Add(Cx);
            points.Add(Dx);
            white.Points = points;
            white.Fill = Brushes.White;
            canv.Children.Add(white);
            // Находим координаты оставшихся 8 квадратов и по ним делаем рекурсию.
            Point A1 = new Point(Ax.X, A.Y);
            Point A2 = new Point(Bx.X, A.Y);
            Point B1 = new Point(B.X, Ax.Y);
            Point B2 = new Point(B.X, Cx.Y);
            Point C1 = new Point(Bx.X, C.Y);
            Point C2 = new Point(Ax.X, C.Y);
            Point D1 = new Point(D.X, Dx.Y);
            Point D2 = new Point(D.X, Ax.Y);
            if (depth > 1)
            {
                DrawCarpet(A, A1, Ax, D2, depth - 1, canv);
                DrawCarpet(A1, A2, Bx, Ax, depth - 1, canv);
                DrawCarpet(A2, B, B1, Bx, depth - 1, canv);
                DrawCarpet(Bx, B1, B2, Cx, depth - 1, canv);
                DrawCarpet(Cx, B2, C, C1, depth - 1, canv);
                DrawCarpet(Dx, Cx, C1, C2, depth - 1, canv);
                DrawCarpet(D1, Dx, C2, D, depth - 1, canv);
                DrawCarpet(D2, Ax, Dx, D1, depth - 1, canv);
            }
            else
                return;
        }
    }
}
