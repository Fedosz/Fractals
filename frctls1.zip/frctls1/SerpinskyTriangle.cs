﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace frctls1
{
    class SerpinskyTriangle : Fractals
    {
        /// <summary>
        /// Создаем новый фрактал 
        /// </summary>
        /// <param name="depth">Глубина фрактала</param>
        /// <param name="name">Название канваса</param>
        public SerpinskyTriangle(int depth, Canvas name) : base(depth, name)
        {
            // Верхняя вершина треугольника.
            Point A = new Point(420, 80);
            // Правая вершина треугольника.
            Point B = new Point(420 + Math.Tan(Math.PI / 6) * 420, 500);
            // Левая вершина треугольника.
            Point C = new Point(420 - Math.Tan(Math.PI / 6) * 420, 500);
            DrawTriangle(A, B, C, depth, name);
        }
        /// <summary>
        /// Рисуем фрактал.
        /// </summary>
        /// <param name="A">Вершина А</param>
        /// <param name="B">Вершина В</param>
        /// <param name="C">Вершина С</param>
        /// <param name="depth">Глубина фрактала</param>
        /// <param name="canv">Канвас</param>
        private void DrawTriangle(Point A, Point B, Point C, int depth, Canvas canv)
        {
            //Создаем линиии и даем им параметры.
            Line AB = new Line();
            (AB.X1, AB.Y1, AB.X2, AB.Y2) = (A.X, A.Y, B.X, B.Y);
            AB.Stroke = Brushes.Blue;
            Line BC = new Line();
            (BC.X1, BC.Y1, BC.X2, BC.Y2) = (B.X, B.Y, C.X, C.Y);
            BC.Stroke = Brushes.Blue;
            Line CA = new Line();
            (CA.X1, CA.Y1, CA.X2, CA.Y2) = (C.X, C.Y, A.X, A.Y);
            CA.Stroke = Brushes.Blue;
            AB.StrokeThickness = 3;
            BC.StrokeThickness = 3;
            CA.StrokeThickness = 3;
            //Добавляем линии на канвас.
            canv.Children.Add(AB);
            canv.Children.Add(BC);
            canv.Children.Add(CA);
            //Находим координаты точек центров отрезков и строим через них новые треугольники.
            Point A1 = new Point((A.X + B.X) / 2, (A.Y + B.Y) / 2);
            Point B1 = new Point((B.X + C.X) / 2, (B.Y + C.Y) / 2);
            Point C1 = new Point((C.X + A.X) / 2, (C.Y + A.Y) / 2);
            if (depth > 0)
            {
                DrawTriangle(A, A1, C1, depth - 1, canv);
                DrawTriangle(A1, B, B1, depth - 1, canv);
                DrawTriangle(C1, B1, C, depth - 1, canv);
            }
            else
                return;
        }
    }
}
