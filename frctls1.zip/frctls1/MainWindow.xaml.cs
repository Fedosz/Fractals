﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace frctls1
{
    /// <summary> 
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Глубина дерева Пифагора.
        private int fractalDepthTree = 4;
        // Глубина фракталов Коха и Кантора.
        private int fractalDepthK = 4;
        // Наклон левой ветки дерева.
        private int degreeLeftIncline = 36;
        // Наклон правой ветки дерева.
        private int degreeRightIncline = 36;
        // Наклон в радианах.
        private double leftIncline = Math.PI / 5;
        private double rightIncline = Math.PI / 5;
        // Коэффициент между итерациями дерева пифагора.
        private double currentCoef = 0.75;
        // Расстояние между отрезками Кантора.
        private int distance = 80;
        // Глубина фракталов Серпинского.
        private int SerpinskyDepth = 4;
        public MainWindow()
        {
            InitializeComponent();
            //Ставим заголовки для всех параметров.
            DepthText.Text = "Текущая глубина: " + fractalDepthTree;
            DepthText2.Text = "Текущая глубина: " + fractalDepthK;
            SerpinskyText.Text = "Текущая глубина: " + SerpinskyDepth;
            DistText.Text = "Текущее расстояние: " + distance + "pt";
            RightBranchText.Text = "Текущий наклон: " + degreeRightIncline + " градусов";
            LeftBranchText.Text = "Текущий наклон: " + degreeLeftIncline + " градусов";
            CurrentCoef.Text = "Текущий коэффициент: " + currentCoef;
        }

        private void FractalTree_Click(object sender, RoutedEventArgs e)
        {
            // Очищаем поле.
            Drawing_field.Children.Clear();
            // Создаем новый фрактал.
            FractalTree tree = new FractalTree(fractalDepthTree, Drawing_field, leftIncline, rightIncline, currentCoef);
        }

        private void KohasFractal_Click(object sender, RoutedEventArgs e)
        {
            Drawing_field.Children.Clear();
            Koha koha = new Koha(fractalDepthK, Drawing_field);
        }

        private void SerpinskyCarpet_Click(object sender, RoutedEventArgs e)
        {
            Drawing_field.Children.Clear();
            SerpinskyCarpet carpet = new SerpinskyCarpet(SerpinskyDepth, Drawing_field);

        }

        private void SerpTriangle_Click(object sender, RoutedEventArgs e)
        {
            Drawing_field.Children.Clear();
            SerpinskyTriangle triangle = new SerpinskyTriangle(SerpinskyDepth, Drawing_field);
        }

        private void CantorSet_Click(object sender, RoutedEventArgs e)
        {
            Drawing_field.Children.Clear();
            CantorSet lines = new CantorSet(fractalDepthK, Drawing_field, distance);
        }
        private void HigherDepth_Click(object sender, RoutedEventArgs e)
        {
            // Если глубина не достигла максимума - увеличиваем.
            if (fractalDepthTree < Fractals.maxDepthTree)
            {
                fractalDepthTree++;
                DepthText.Text = "Текущая глубина: " + fractalDepthTree;
            }
            else
            {
                MessageBox.Show("Выбрана максимальная глубина", "Ошибка!");
            }
        }

        private void LowerDepth_Click(object sender, RoutedEventArgs e)
        {
            if (fractalDepthTree > 0)
            {
                fractalDepthTree--;
                DepthText.Text = "Текущая глубина: " + fractalDepthTree;
            }
            else
            {
                MessageBox.Show("Выбрана минимальная глубина", "Ошибка!");
            }
        }
        private void HigherRightBranch_Click(object sender, RoutedEventArgs e)
        {
            if (degreeRightIncline + 4 <= 56)
            {
                degreeRightIncline += 4;
                rightIncline += Math.PI / 45;
                RightBranchText.Text = "Текущий наклон: " + degreeRightIncline + " градусов";
            }
            else
                MessageBox.Show("Выбран максимальный наклон", "Ошибка!");

        }

        private void LowerRightBranch_Click(object sender, RoutedEventArgs e)
        {
            if (degreeRightIncline - 4 >= 16)
            {
                degreeRightIncline -= 4;
                rightIncline -= Math.PI / 45;
                RightBranchText.Text = "Текущий наклон: " + degreeRightIncline + " градусов";
            }
            else
                MessageBox.Show("Выбран минимальный наклон", "Ошибка!");
        }

        private void HigherLeftBranch_Click(object sender, RoutedEventArgs e)
        {
            if (degreeLeftIncline + 4 <= 56)
            {
                degreeLeftIncline += 4;
                leftIncline += Math.PI / 45;
                LeftBranchText.Text = "Текущий наклон: " + degreeLeftIncline + " градусов";
            }
            else
                MessageBox.Show("Выбран максимальный наклон", "Ошибка!");
        }

        private void LowerLeftBranch_Click(object sender, RoutedEventArgs e)
        {
            if (degreeLeftIncline - 4 >= 16)
            {
                degreeLeftIncline -= 4;
                leftIncline -= Math.PI / 45;
                LeftBranchText.Text = "Текущий наклон: " + degreeLeftIncline + " градусов";
            }
            else
                MessageBox.Show("Выбран минимальный наклон", "Ошибка!");
        }

        private void HigherCoef_Click(object sender, RoutedEventArgs e)
        {
            if (currentCoef + 0.05 <= 0.81)
            {
                currentCoef += 0.05;
                currentCoef = Math.Round(currentCoef, 2);
                CurrentCoef.Text = "Текущий коэффициент: " + currentCoef;
            }
            else
                MessageBox.Show("Выбран максимальный коэффициент", "Ошибка!");
        }

        private void LowerCoef_Click(object sender, RoutedEventArgs e)
        {
            if (currentCoef - 0.05 >= 0.6)
            {
                currentCoef -= 0.05;
                currentCoef = Math.Round(currentCoef, 2);
                CurrentCoef.Text = "Текущий коэффициент: " + currentCoef;
            }
            else
                MessageBox.Show("Выбран минимальный коэффициент", "Ошибка!");
        }

        private void HigherDepth1_Click(object sender, RoutedEventArgs e)
        {
            if (SerpinskyDepth < 5)
            {
                SerpinskyDepth++;
                SerpinskyText.Text = "Текущая глубина: " + SerpinskyDepth;
            }
            else
            {
                MessageBox.Show("Выбрана максимальная глубина", "Ошибка!");
            }
        }

        private void LowerDepth1_Click(object sender, RoutedEventArgs e)
        {
            if (SerpinskyDepth > 0)
            {
                SerpinskyDepth--;
                SerpinskyText.Text = "Текущая глубина: " + SerpinskyDepth;
            }
            else
            {
                MessageBox.Show("Выбрана минимальная глубина", "Ошибка!");
            }
        }

        private void HigherDepth2_Click(object sender, RoutedEventArgs e)
        {
            if (fractalDepthK < 6)
            {
                fractalDepthK++;
                DepthText2.Text = "Текущая глубина: " + fractalDepthK;
            }
            else
            {
                MessageBox.Show("Выбрана максимальная глубина", "Ошибка!");
            }
        }

        private void LowerDepth2_Click(object sender, RoutedEventArgs e)
        {
            if (fractalDepthK > 0)
            {
                fractalDepthK--;
                DepthText2.Text = "Текущая глубина: " + fractalDepthK;
            }
            else
            {
                MessageBox.Show("Выбрана минимальная глубина", "Ошибка!");
            }
        }

        private void HigherDist_Click(object sender, RoutedEventArgs e)
        {
            if (distance < 100)
            {
                distance += 5;
                DistText.Text = "Текущее расстояние: " + distance + "pt";
            }
            else
                MessageBox.Show("Выбрано максимальное расстояние", "Ошибка!");
        }

        private void LowerDist_Click(object sender, RoutedEventArgs e)
        {
            if (distance > 50)
            {
                distance -= 5;
                DistText.Text = "Текущее расстояние: " + distance + "pt";
            }
            else
                MessageBox.Show("Выбрано минимальное расстояние", "Ошибка!");
        }
    }
     class Fractals
    {
        // Глубина фрактала.
        protected int Depth;
        // Максимальная глубина фрактала.
        public static int maxDepthTree = 14;
        // Текущее поле для рисования.
        internal Canvas currentPanel;
        public Fractals(int depth, Canvas name)
        {
            this.Depth = depth;
            this.currentPanel = name;
        }
    }
}
